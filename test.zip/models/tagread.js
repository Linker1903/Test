const mongoose = require('mongoose')

const tagreadSchema = new mongoose.Schema({
    epc: {
        type: String,
        required: true
    },
    antenna: {
        type: Number,
        required: true
    }
})

module.exports = mongoose.model('tagread', tagreadSchema)