const express = require('express')
const router = express.Router()
const Tagread = require('../models/tagread')



// Creating one
router.post('/', async (req, res) => {
    const tagread = new Tagread({
        epc: req.body.epc,
        antenna: req.body.antenna
    })
    try {
        const newTagread = await tagread.save()
        res.status(200).json(newTagread)
    } catch (err) {
        res.status(400).json({ message: err.message })
    }
})


module.exports = router